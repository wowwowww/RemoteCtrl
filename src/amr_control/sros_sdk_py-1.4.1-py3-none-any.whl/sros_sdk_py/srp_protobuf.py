import logging
import hashlib
import math

from enum import Enum, IntEnum

from . import main_pb2
from . import frame as srp_frame
from typing import Any
from dataclasses import dataclass


_logger = logging.getLogger(__name__)


@dataclass
class RespData:
    resp_type: main_pb2.Response.ResponseType
    ok: bool
    value: Any | None
    result_code: int

    def __str__(self):
        return (
            f"RespData(resp_type='{self.resp_type}', ok={self.ok}, value={self.value}, result_code={self.result_code})"
        )


class HMIUserSetState(IntEnum):
    NONE = 0x0
    WAITING_FOR_ELEVATOR = 0x1  # 等待电梯
    DISINGECTING = 0x2  # 正在消毒
    FMS_DISCONNECTED = 0x3  # 调度系统掉线
    WHERE_AM_I = 0x4  # 寻找机器人
    IN_TRAFFIC_CONTROL_ = 0x5  # 交通管制中


class SrpProtobuf:
    """本类处理protobuf协议的解析"""

    def __init__(self, write_callback, response_callback):
        self._session_id = 0
        self._frame = srp_frame.Frame(self._onNewMessageCallback)
        self._write = write_callback
        self._response_callback = response_callback
        self._system_state_callback = None
        self._hardware_state_callback = None
        self._sensor_samples_callback = None
        self._laser_point_callback = None
        self._notify_move_task_finished_callback = None
        self._notify_action_task_finished_callback = None
        self._notify_mission_list_change_callback = None

        self._last_action_state = main_pb2.ActionTask.TaskState.AT_ZERO

    def set_system_state_callback(self, fun):
        self._system_state_callback = fun

    def set_hardware_state_callback(self, fun):
        self._hardware_state_callback = fun

    def set_sensor_samples_callback(self, fun):
        self._sensor_samples_callback = fun

    def set_laser_point_callback(self, fun):
        self._laser_point_callback = fun

    def set_notify_move_task_finished_callback(self, fun):
        self._notify_move_task_finished_callback = fun

    def set_notify_action_task_finished_callback(self, fun):
        self._notify_action_task_finished_callback = fun

    def set_notify_mission_list_change_callback(self, fun):
        self._notify_mission_list_change_callback = fun

    def onRead(self, data):
        self._frame.setNewFrame(data)

    def login(self, seq, user_name, passwd):
        md5 = hashlib.md5()
        md5.update(passwd.encode('utf8'))

        login_request = main_pb2.LoginRequest(username=user_name, password=md5.hexdigest())
        self._sendRequestMsg(seq, main_pb2.Request.REQUEST_LOGIN, login_request=login_request)

    def logout(self, seq):
        self._sendRequestMsg(seq, main_pb2.Request.REQUEST_LOGOUT)

    def get_hardware_state(self, seq):
        return self._sendRequestMsg(seq, main_pb2.Request.REQUEST_HARDWARE_STATE)

    def get_system_state(self, seq):
        return self._sendRequestMsg(seq, main_pb2.Request.REQUEST_SYSTEM_STATE)

    def get_info(self, seq):
        self._sendRequestMsg(seq, main_pb2.Request.REQUEST_INFO)

    def get_sensor_samples(self, seq):
        self._sendRequestMsg(seq, main_pb2.Request.REQUEST_SENSOR_SAMPLES)

    def get_laser_points(self, seq):
        self._sendRequestMsg(seq, main_pb2.Request.REQUEST_LASER_POINTS)

    def get_camera_sample(self, seq, camera_id):
        self._sendRequestMsg(seq, main_pb2.Request.REQUEST_GET_CAMERA_PICTURE, param_int=camera_id)

    def get_sros_config(self, seq):
        self._sendRequestMsg(seq, main_pb2.Request.REQUEST_LOAD_CONFIG)

    def set_sros_cache_configs(self, seq, configs):
        self._sendRequestMsg(seq, main_pb2.Request.REQUEST_SAVE_TMP_CONFIG, cache_configs=configs)

    def move_pause(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_PAUSE_MOVEMENT)

    def move_continue(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_CONTINUE_MOVEMENT)

    def setEmergency(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_TRIGGER_EMERGENCY)

    def cancelEmergencyState(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_CANCEL_EMERGENCY)

    def start_charge(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_ENABLE_AUTO_CHARGE)

    def stop_charge(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_STOP_CHARGE)

    def reset_srp(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_RESET_SRP)

    def move_to_station(self, seq, no, station_id, avoid_policy=main_pb2.MovementTask.OBSTACLE_AVOID_WAIT):
        movement_task = main_pb2.MovementTask(
            no=no,
            type=main_pb2.MovementTask.MT_MOVE_TO_STATION,
            stations=[station_id],
            avoid_policy=avoid_policy,
        )

        self._send_command_msg(seq, main_pb2.CMD_NEW_MOVEMENT_TASK, movement_task=movement_task)

    def move_follow_path(
        self,
        seq,
        no,
        paths,
        cancel_task_decetect_dmcode,
        avoid_policy=main_pb2.MovementTask.OBSTACLE_AVOID_WAIT,
    ):
        # _logger.info("Move follow path, task no %d" % no)
        movement_task = main_pb2.MovementTask(
            no=no, type=main_pb2.MovementTask.MT_MOVE_FOLLOW_PATH, avoid_policy=avoid_policy
        )
        for path in paths:
            proto_path = movement_task.paths.add()
            proto_path.type = path.type.value
            proto_path.sx = path.sx
            proto_path.sy = path.sy
            proto_path.ex = path.ex
            proto_path.ey = path.ey
            proto_path.cx = path.cx
            proto_path.cy = path.cy
            proto_path.dx = path.dx
            proto_path.dy = path.dy
            proto_path.radius = path.radius
            proto_path.rotate_angle = path.rotate_angle
            if isinstance(path.direction, Enum):
                proto_path.direction = path.direction.value
            else:
                proto_path.direction = path.direction
            proto_path.limit_v = path.limit_v
            proto_path.limit_w = path.limit_w
            proto_path.load_orientation_policy = path.load_orientation_policy.value
            proto_path.load_orientation = path.load_orientation
            proto_path.orientation = path.orientation

        self._send_command_msg(
            seq,
            main_pb2.CMD_NEW_MOVEMENT_TASK,
            movement_task=movement_task,
        )

    def move_pod_code(self, seq, no, load_type: str):
        movement_task = main_pb2.MovementTask(no=no, load_type=load_type)
        self._send_command_msg(seq, main_pb2.CMD_NEW_MOVEMENT_TASK, movement_task=movement_task)

    def enable_manual_control_oba(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_ENABLE_MANUAL_CONTROL_OBA)

    def disable_manual_control_oba(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_DISABLE_MANUAL_CONTROL_OBA)

    # 追加路径，以支持发送多段路径时移动连续
    def replace_move_path(self, seq, no, paths, cancel_task_decetect_dmcode):
        proto_paths = []
        for path in paths:
            proto_path = main_pb2.Path()
            proto_path.type = path.type.value
            proto_path.sx = path.sx
            proto_path.sy = path.sy
            proto_path.ex = path.ex
            proto_path.ey = path.ey
            proto_path.cx = path.cx
            proto_path.cy = path.cy
            proto_path.dx = path.dx
            proto_path.dy = path.dy
            proto_path.radius = path.radius
            proto_path.rotate_angle = path.rotate_angle
            proto_path.direction = path.direction.value
            proto_path.limit_v = path.limit_v
            proto_path.limit_w = path.limit_w
            proto_paths.append(proto_path)
        self._send_command_msg(
            seq,
            main_pb2.CMD_PATH_REPLACE,
            paramInt=no,
            paths=proto_paths,
            paramInt1=cancel_task_decetect_dmcode,
        )

    def pause_task(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_PAUSE_MOVEMENT)

    def continue_task(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_CONTINUE_MOVEMENT)

    def cancel_task(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_COMMON_CANCEL)

    def cancel_movement_task(self, seq, soft_cancel):
        self._send_command_msg(seq, main_pb2.CMD_CANCEL_MOVEMENT_TASK, paramBool=soft_cancel)

    def set_schedule_mode(self, seq, mode):
        self._send_command_msg(seq, main_pb2.CMD_SET_SCHEDULING_MODE, paramInt=mode, paramBool=False)

    def set_manual_speed(self, seq, vx, vy, w, cur_angle):
        # vx: mm/s 线速度，w mrad/s
        self._send_command_msg(seq, main_pb2.CMD_SET_MANUAL_SPEED, paramInt=vx, paramInt1=w, paramInt2=0, paramInt3=vy)

    def enable_manual_control(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_ENABLE_MANUAL_CONTROL)

    def disable_manual_control(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_DISABLE_MANUAL_CONTROL)

    def enable_traffic_control(self, seq, hold_time_ms=2500):
        # 开启交管状态后需要一直设置来保持交管，默认状态持续时间 2.5s
        self._send_command_msg(
            seq,
            main_pb2.CMD_SET_HMI_STATE,
            paramInt=HMIUserSetState.IN_TRAFFIC_CONTROL_,
            paramInt1=hold_time_ms,
            paramBool=True,
        )

    def disable_traffic_control(self, seq):
        self._send_command_msg(
            seq,
            main_pb2.CMD_SET_HMI_STATE,
            paramInt=HMIUserSetState.IN_TRAFFIC_CONTROL_,
            paramBool=False,
        )

    def execute_action_task(self, seq, no, action_id, param0, param1, param_str=''):
        action_task = main_pb2.ActionTask(no=no, id=action_id, param0=param0, param1=param1, param_str=param_str)
        self._send_command_msg(seq, main_pb2.CMD_NEW_ACTION_TASK, action_task=action_task)

    def cancel_action_task(self, seq):
        self._send_command_msg(seq, main_pb2.CMD_CANCEL_ACTION_TASK)

    def readInputRegisters(self, seq, start_addr, count):
        self._sendRequestMsg(
            seq,
            main_pb2.Request.REQUEST_READ_INPUT_REGISTER,
            param_int=start_addr,
            param_int1=count,
        )

    def readHoldRegisters(self, seq, start_addr, count):
        self._sendRequestMsg(
            seq,
            main_pb2.Request.REQUEST_READ_HOLDING_REGISTERS,
            param_int=start_addr,
            param_int1=count,
        )

    def stop_location(self, seq):
        _logger.info(f'stop location {seq}')
        self._send_command_msg(seq, main_pb2.CMD_STOP_LOCATION)

    def set_current_map(self, seq, map_name):
        _logger.info(f'set current map seq: {seq}, map name: {map_name}')
        self._send_command_msg(seq, main_pb2.CMD_SET_CUR_MAP, paramStr=map_name)

    def set_current_station(self, seq, station_id):
        _logger.info(f'set current station seq: {seq}, station id: {station_id}')
        self._send_command_msg(seq, main_pb2.CMD_SET_CUR_STATION, paramInt=station_id)

    def start_location(self, seq, absolute_location=False, station_id: int | None = None):
        _logger.info(f'start location {seq}')
        self._send_command_msg(
            seq,
            main_pb2.CMD_START_LOCATION,
            paramBool=absolute_location,
            paramInt=station_id,
        )

    def switch_map(self, seq, map_name, x, y, yaw, absolute_location=False):
        _logger.info(f'switch map seq: {seq}, new map: {map_name}')
        pose = main_pb2.Pose(x=x, y=y, yaw=int(yaw * 1000))
        self._send_command_msg(
            seq,
            main_pb2.CMD_MAP_SWITCHING,
            paramBool=absolute_location,
            paramStr=map_name,
            pose=pose,
        )

    def set_initial_pose(self, seq, x, y, yaw, x_factor, y_factor):
        pose = main_pb2.Pose(x=x, y=y, yaw=int(yaw * 1000))
        self._send_command_msg(
            seq,
            main_pb2.CMD_SET_LOCATION_INITIAL_POSE,
            paramInt=x_factor,
            paramInt1=y_factor,
            pose=pose,
        )

    def _send_command_msg(
        self,
        seq,
        cmdType,
        paramInt=None,
        paramInt1=None,
        paramStr=None,
        pose=None,
        movement_task=None,
        action_task=None,
        missionLst=None,
        lockerIP=None,
        lockerNickname=None,
        paths=None,
        paramBool=False,
        paramInt2=None,
        paramInt3=None,
    ):
        command = main_pb2.Command(
            command=cmdType,
            param_int=paramInt,
            param_int1=paramInt1,
            pose=pose,
            movement_task=movement_task,
            action_task=action_task,
            param_str=paramStr,
            mission_list=missionLst,
            locker_ip_address=lockerIP,
            locker_nickname=lockerNickname,
            paths=paths,
            param_boolean=paramBool,
            param_int2=paramInt2,
            param_int3=paramInt3,
        )

        message = main_pb2.Message(type=main_pb2.MSG_COMMAND, seq=seq, session_id=self._session_id, command=command)

        self._sendMsg(message)

    def _sendRequestMsg(
        self,
        seq,
        request_type,
        login_request=None,
        file_op=None,
        param_str=None,
        param_str1=None,
        config=None,
        param_int=None,
        param_int1=None,
        cache_configs=None,
    ):
        request = main_pb2.Request(
            request_type=request_type,
            login_request=login_request,
            file_op=file_op,
            param_str=param_str,
            param_str1=param_str1,
            param_int=param_int,
            param_int1=param_int1,
            config=config,
        )

        if cache_configs:
            for c in cache_configs:
                config = request.tmp_configs.add()
                config.key = c['key']
                config.value = c['value']

        message = main_pb2.Message(type=main_pb2.MSG_REQUEST, seq=seq, session_id=self._session_id, request=request)

        self._sendMsg(message)

    def _send_response_msg(self, response_type, seq, notify_type):
        notification_response = main_pb2.NotifyResponse(ack=True, type=notify_type)

        response = main_pb2.Response(response_type=response_type, notify_response=notification_response)
        message = main_pb2.Message(type=main_pb2.MSG_RESPONSE, seq=seq, session_id=self._session_id, response=response)

        self._sendMsg(message)

    def _sendMsg(self, message: main_pb2.Message):
        msg = message.SerializeToString()
        frame = srp_frame.Frame.buildFrame(msg)
        self._write(frame)

    def _handleRecvResponseMsg(self, msg: main_pb2.Message):
        response = msg.response
        value = {}
        if response.response_type == main_pb2.Response.RESPONSE_LASER_POINTS:
            if self._laser_point_callback:
                self._laser_point_callback(response.laser_points)
            value = response.laser_points
            ok = response.result.result_state != main_pb2.ResponseResult.RESPONSE_FAILED
            self._response_callback(
                msg.seq,
                RespData(
                    resp_type=response.response_type,
                    ok=ok,
                    value=value,
                    result_code=response.result.result_code,
                ),
            )
            return

        if response.result.result_state in (
            main_pb2.ResponseResult.RESPONSE_OK,
            main_pb2.ResponseResult.RESPONSE_PROCESSING,
        ):
            if response.response_type == main_pb2.Response.RESPONSE_LOGIN:
                self._session_id = msg.session_id
            elif response.response_type == main_pb2.Response.RESPONSE_LOAD_CONFIG:
                value = list(response.config)
            elif response.response_type == main_pb2.Response.RESPONSE_SYSTEM_STATE:
                system_state = response.system_state
                if self._system_state_callback is not None:
                    self._system_state_callback(system_state)
                value = system_state
            elif response.response_type == main_pb2.Response.RESPONSE_HARDWARE_STATE:
                if self._hardware_state_callback:
                    self._hardware_state_callback(response.hardware_state)
                value = response.hardware_state
            elif response.response_type == main_pb2.Response.RESPONSE_READ_HOLDING_REGISTERS:
                value = response.registers_values.hold_registers
            elif response.response_type == main_pb2.Response.RESPONSE_READ_INPUT_REGISTER:
                value = response.registers_values.input_registers
            elif response.response_type == main_pb2.Response.RESPONSE_INFO:
                value = response.info
            elif response.response_type == main_pb2.Response.RESPONSE_SENSOR_SAMPLES:
                if self._sensor_samples_callback:
                    self._sensor_samples_callback(response.sensor_samples)
                value = response.sensor_samples
            elif response.response_type == main_pb2.Response.RESPONSE_GET_CAMERA_PICTURE:
                value = response.camera_meta_info
            ok = True
        elif response.result.result_state == main_pb2.ResponseResult.RESPONSE_FAILED:
            ok = False
        else:
            # _logger.error(f'unknown response {response}')
            return

        self._response_callback(
            msg.seq,
            RespData(
                resp_type=response.response_type,
                ok=ok,
                value=value,
                result_code=response.result.result_code,
            ),
        )

    def _ack_notification(self, message):
        if message.seq <= 0:
            return
        self._send_response_msg(main_pb2.Response.RESPONSE_NOTIFY, message.seq, message.notification.notify_type)

    def _handle_recv_notification_msg(self, notification):
        _logger.info(f'on notify message: {notification.notify_type}')
        if notification.notify_type == main_pb2.Notification.NOTIFY_MOVE_TASK_FINISHED:
            if self._notify_move_task_finished_callback is not None:
                self._notify_move_task_finished_callback(notification)
        elif notification.notify_type == main_pb2.Notification.NOTIFY_ACTION_TASK_FINISHED:
            if self._notify_action_task_finished_callback is not None:
                self._notify_action_task_finished_callback(notification)
        elif notification.notify_type == main_pb2.Notification.NOTIFY_MISSION_LIST_CHANGED:
            if self._notify_mission_list_change_callback is not None:
                self._notify_mission_list_change_callback(notification.mission_list)
        else:
            _logger.error(f'UNRACHABLE! notify type: {notification.notify_type}')

    def _onNewMessageCallback(self, msg):
        try:
            message = main_pb2.Message()
            message.ParseFromString(msg)
        except BaseException as e:
            _logger.error(e)
            raise e

        if message.type == main_pb2.MSG_RESPONSE:
            self._handleRecvResponseMsg(message)
        elif message.type == main_pb2.MSG_NOTIFICATION:
            self._ack_notification(message)
            self._handle_recv_notification_msg(message.notification)
        else:
            _logger.error(f'UNREACHABLE! {message.type}')

    def is_last_action_state_running(self):
        return self._last_action_state in (
            main_pb2.ActionTask.TaskState.AT_WAIT_FOR_START,
            main_pb2.ActionTask.TaskState.AT_RUNNING,
            main_pb2.ActionTask.TaskState.AT_PAUSED,
            main_pb2.ActionTask.TaskState.AT_IN_CANCEL,
            main_pb2.ActionTask.TaskState.AT_TASK_WAIT_FOR_ACK,
        )
