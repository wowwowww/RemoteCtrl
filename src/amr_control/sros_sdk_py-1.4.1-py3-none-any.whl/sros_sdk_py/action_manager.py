import time
from dataclasses import asdict, dataclass
from threading import Condition
from typing import Any, Optional

from .main_pb2 import ActionTask, SystemState, TaskResult


@dataclass
class ActionExecutionStatus:
    action_no: int
    action_id: int
    param0: int
    param1: int
    param_str: str = ''
    status: str = 'PENDING'
    state: int = ActionTask.TaskState.AT_ZERO
    result: int = TaskResult.TASK_RESULT_NA
    result_code: int = 0
    result_str: str = ''
    revision: int = 0
    started_at: float = 0.0
    updated_at: float = 0.0
    finished_at: Optional[float] = None


class ActionManager:
    """Track SRP action task lifecycle for upper-layer long polling."""

    def __init__(self):
        self._cv = Condition()
        self._actions: dict[int, ActionExecutionStatus] = {}

    def submit_action(self, action_no: int, action_id: int, param0: int, param1: int, param_str: str = ''):
        now = time.time()
        with self._cv:
            current = self._actions.get(action_no)
            if current and not self._is_final(current.status):
                raise ValueError(f'action_no={action_no} is still running')

            status = ActionExecutionStatus(
                action_no=action_no,
                action_id=action_id,
                param0=param0,
                param1=param1,
                param_str=param_str,
                status='SUBMITTED',
                started_at=now,
                updated_at=now,
                revision=1,
            )
            self._actions[action_no] = status
            self._cv.notify_all()
            return asdict(status)

    def mark_rejected(self, action_no: int, result_code: int, result_str: str = ''):
        with self._cv:
            status = self._get_or_create(action_no)
            status.status = 'REJECTED'
            status.result = TaskResult.TASK_RESULT_FAILED
            status.result_code = result_code
            status.result_str = result_str
            status.finished_at = time.time()
            self._touch(status)

    def on_system_state(self, system_state: SystemState):
        if not system_state.HasField('action_state'):
            return

        action_state = system_state.action_state
        if action_state.no <= 0:
            return

        with self._cv:
            status = self._get_or_create(action_state.no)
            changed = self._apply_action_task(status, action_state)
            if self._is_final(status.status):
                status.finished_at = time.time()
            if changed:
                self._touch(status)

    def on_action_finished(self, action_task: ActionTask):
        if action_task.no <= 0:
            return

        with self._cv:
            status = self._get_or_create(action_task.no)
            changed = self._apply_action_task(status, action_task)
            status.finished_at = time.time()
            if changed:
                self._touch(status)

    def get_action_status(self, action_no: int) -> Optional[dict[str, Any]]:
        with self._cv:
            status = self._actions.get(action_no)
            if not status:
                return None
            return asdict(status)

    def wait_action_update(self, action_no: int, timeout: float = 30.0, after_revision: Optional[int] = None):
        deadline = time.time() + max(timeout, 0.0)

        with self._cv:
            status = self._actions.get(action_no)

            if after_revision is None:
                return {
                    'changed': status is not None,
                    'timeout': False,
                    'action': asdict(status) if status else None,
                }

            while True:
                status = self._actions.get(action_no)
                if status and status.revision > after_revision:
                    return {
                        'changed': True,
                        'timeout': False,
                        'action': asdict(status),
                    }

                remaining = deadline - time.time()
                if remaining <= 0:
                    return {
                        'changed': False,
                        'timeout': True,
                        'action': asdict(status) if status else None,
                    }

                self._cv.wait(timeout=remaining)

    def _get_or_create(self, action_no: int):
        status = self._actions.get(action_no)
        if status:
            return status
        now = time.time()
        status = ActionExecutionStatus(
            action_no=action_no,
            action_id=0,
            param0=0,
            param1=0,
            started_at=now,
            updated_at=now,
        )
        self._actions[action_no] = status
        return status

    @staticmethod
    def _status_from_action_task(action_task: ActionTask) -> str:
        if action_task.state in (
            ActionTask.TaskState.AT_WAIT_FOR_START,
            ActionTask.TaskState.AT_TASK_WAIT_FOR_ACK,
        ):
            return 'WAITING'
        if action_task.state in (
            ActionTask.TaskState.AT_RUNNING,
            ActionTask.TaskState.AT_PAUSED,
            ActionTask.TaskState.AT_IN_CANCEL,
        ):
            return 'RUNNING'
        if action_task.state == ActionTask.TaskState.AT_FINISHED:
            if action_task.result == TaskResult.TASK_RESULT_OK:
                return 'SUCCEEDED'
            if action_task.result == TaskResult.TASK_RESULT_CANCELED:
                return 'CANCELED'
            return 'FAILED'
        if action_task.result == TaskResult.TASK_RESULT_OK:
            return 'SUCCEEDED'
        if action_task.result == TaskResult.TASK_RESULT_CANCELED:
            return 'CANCELED'
        if action_task.result == TaskResult.TASK_RESULT_FAILED:
            return 'FAILED'
        return 'PENDING'

    def _apply_action_task(self, status: ActionExecutionStatus, action_task: ActionTask):
        before = (
            status.action_id,
            status.param0,
            status.param1,
            status.param_str,
            status.state,
            status.result,
            status.result_code,
            status.result_str,
            status.status,
        )

        status.action_id = action_task.id
        status.param0 = action_task.param0
        status.param1 = action_task.param1
        status.param_str = action_task.param_str
        status.state = action_task.state
        status.result = action_task.result
        status.result_code = action_task.result_code
        status.result_str = action_task.result_str
        status.status = self._status_from_action_task(action_task)

        after = (
            status.action_id,
            status.param0,
            status.param1,
            status.param_str,
            status.state,
            status.result,
            status.result_code,
            status.result_str,
            status.status,
        )
        return before != after

    def _touch(self, status: ActionExecutionStatus):
        status.revision += 1
        status.updated_at = time.time()
        self._cv.notify_all()

    @staticmethod
    def _is_final(status: str):
        return status in ('SUCCEEDED', 'FAILED', 'CANCELED', 'REJECTED')
