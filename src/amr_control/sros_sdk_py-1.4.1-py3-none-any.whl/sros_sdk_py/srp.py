import asyncio
import logging
import socket
import threading
from collections.abc import Callable
from dataclasses import dataclass
from typing import Optional

from . import main_pb2, srp_protobuf

_logger = logging.getLogger(__name__)


@dataclass
class RequestContext:
    sequence: int
    callback: Callable[[srp_protobuf.RespData], None] | None = None
    future: asyncio.Future | None = None


class RequestFailedError(Exception):
    def __init__(self, value, result_code: int = 0):
        self.value = value
        self.result_code = result_code
        super().__init__(f'sync request reject, error code: {result_code}')


class SrpProtocol(asyncio.Protocol):
    def __init__(self, srp: 'SRP'):
        self._srp = srp

    def connection_made(self, transport):
        self._srp.connection_made(transport)

    def data_received(self, data):
        self._srp.data_received(data)

    def error_received(self, exc):
        self._srp.error_received(exc)

    def connection_lost(self, exc):
        self._srp.connection_lost(exc)


class SRP:
    """
    @describe:  本类用来和sros通信
                本类内部有一个线程用于处理protobuf协议的解析、收发，本类是线程安全的
                本类的方法既支持同步通信的方式也支持异步通信的方式，同步通信的方式主要用来测试，比如连续发送task而不等回复
                默认为异步函数，同步函数前面都加了前缀:sync_,和node.js的库命名规范类似
    @NOTE: 异步调用时，假定不会同时调用， 现在只有一个AsyncResult类来阻塞等待sros的响应
    """

    _loop: asyncio.AbstractEventLoop
    _task_future: Optional[asyncio.Future] = None  # 同步等待任务（动作）执行结束
    _loc_future: Optional[asyncio.Future] = None  # 取消定位、定位同步结果
    _transport: Optional[asyncio.Transport] = None
    _protocol: SrpProtocol

    def __init__(self):
        self._protobuf = srp_protobuf.SrpProtobuf(self.write_callback, self.response_callback)
        self._protobuf.set_system_state_callback(self.on_system_state)
        self._protobuf.set_notify_move_task_finished_callback(self.on_move_task_finish)
        self._protobuf.set_notify_action_task_finished_callback(self.on_action_task_finish)

        self._last_location_state = main_pb2.SystemState.LocationState.LOCATION_STATE_ZERO

        self._callback_system_state = None
        self._callback_connect_changed = None
        self._callback_move_task_finish = None
        self._callback_action_task_finish = None

        self._seq: int = 0
        self._seq_ctx_map: dict[int, RequestContext] = {}

        loop_ready = threading.Event()

        def start_loop():
            # create loop in the new thread
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)

            # rely on the thread event loop to be set
            loop_ready.set()

            try:
                self._loop.run_forever()
            finally:
                for task in asyncio.all_tasks(self._loop):
                    task.cancel()
                self._loop.run_until_complete(self._loop.shutdown_asyncgens())
                self._loop.close()

        self._thread = threading.Thread(target=start_loop, name='srp')
        self._thread.start()

        loop_ready.wait()

    def stop(self):
        self._loop.call_soon_threadsafe(self._loop.stop)
        self._thread.join()

    def set_callback_connect(self, fun):
        self._callback_connect_changed = fun

    def set_system_state_callback(self, fun):
        self._callback_system_state = fun

    def set_hardware_state_callback(self, fun):
        self._protobuf.set_hardware_state_callback(fun)

    def set_sensor_samples_callback(self, fun):
        self._protobuf.set_sensor_samples_callback(fun)

    def set_laser_point_callback(self, fun):
        self._protobuf.set_laser_point_callback(fun)

    def set_notify_move_task_finished_callback(self, fun):
        self._callback_move_task_finish = fun

    def set_notify_action_task_finished_callback(self, fun):
        self._callback_action_task_finish = fun

    def set_notify_mission_list_change_callback(self, fun):
        self._protobuf.set_notify_mission_list_change_callback(fun)

    def on_system_state(self, sys_state):
        self._last_location_state = sys_state.location_state
        if self._callback_system_state:
            self._callback_system_state(sys_state)

    def on_move_task_finish(self, notification):
        if self._callback_move_task_finish:
            self._callback_move_task_finish(notification.movement_task)

    def on_action_task_finish(self, notification):
        action_task = notification.action_task
        # 通知同步等待者（若存在）
        if self._task_future is not None and not self._task_future.done():
            self._task_future.set_result(action_task)
            self._task_future = None

        # 无论是否有同步等待者，都需要把动作结束事件分发给上层
        if self._callback_action_task_finish:
            self._callback_action_task_finish(action_task)

    def set_location_result(self, result):
        # do nothing
        if not self._loc_future:
            return
        if self._loc_future.done():
            _logger.warning('set_location_result called on a future that is already done. Result: %s', result)
            return
        _logger.info(f'Set location result: {result}')
        if result:
            self._loc_future.set_result(result)
        else:
            self._loc_future.set_exception(RequestFailedError(value=result))

    @property
    def seq(self) -> int:
        self._seq += 1
        if self._seq > 2**32 - 1:
            self._seq = 1
        return self._seq

    def login(self, ip_addr, user_name, passwd) -> bool:
        """
        登录sros
        :param ip_addr: target sros's ip address
        :param user_name: clear text
        :param passwd: clear text
        :return: none
        """
        try:
            f = asyncio.run_coroutine_threadsafe(self._connect(ip_addr), self._loop)
            result = f.result(3)
            if not result:
                return False
            _logger.info(f'Connect succeed: {ip_addr}:5001')
        except BaseException as e:
            _logger.error(f'srp connect exception: {e}')
            return False

        try:
            self._run_sync_threadsafe(self._protobuf.login, user_name, passwd)
            if self._callback_connect_changed:
                self._callback_connect_changed(True)
            return True
        except BaseException as e:
            _logger.error(f'Login sros failed: {e}')
        return False

    def logout(self):
        if not self._transport or self._transport.is_closing():
            return
        try:
            if threading.current_thread() == self._thread:
                self._protobuf.logout(self.seq)
            else:
                self._run_sync_threadsafe(self._protobuf.logout)
        except BaseException as e:
            _logger.error(f'Logout packet send failed: {e}')
        finally:
            if self._transport:
                self._transport.close()
                self._transport = None

            if self._callback_connect_changed:
                self._callback_connect_changed(False)

    def fetch_system_state(self):
        return self._run_sync_threadsafe(self._protobuf.get_system_state)

    def fetch_hardware_state(self):
        return self._run_sync_threadsafe(self._protobuf.get_hardware_state)

    def fetch_sensor_samples(self):
        return self._run_sync_threadsafe(self._protobuf.get_sensor_samples)

    def fetch_laser_points(self):
        return self._run_sync_threadsafe(self._protobuf.get_laser_points)

    def fetch_camera_sample(self, camera_id):
        return self._run_sync_threadsafe(self._protobuf.get_camera_sample, camera_id)

    def get_sros_config(self, key):
        configs = self._run_sync_threadsafe(self._protobuf.get_sros_config)
        for config in configs:
            if config.key == key:
                return config.value
        return None

    # TODO 没有考虑配置参数没有找到的情况
    def get_sros_configs(self, keys: list) -> dict:
        configs = self._run_sync_threadsafe(self._protobuf.get_sros_config)
        result = {}
        for config in configs:
            for key in keys:
                if config.key == key:
                    result[key] = config.value
        return result

    def get_related_device_id(self, key):
        configs = self._run_sync_threadsafe(self._protobuf.get_sros_config)
        for config in configs:
            if config.key == key:
                return config.related_device_id
        return None

    def set_sros_cache_configs(self, configs):
        self._run_sync_threadsafe(self._protobuf.set_sros_cache_configs, configs)

    def get_info(self):
        info = self._run_sync_threadsafe(self._protobuf.get_info)
        return info

    def trigger_emergency(self):
        self._run_sync_threadsafe(self._protobuf.setEmergency)

    def cancel_emergency(self):
        self._run_sync_threadsafe(self._protobuf.cancelEmergencyState)

    def move_to_station(self, no, station_id, avoid_policy=main_pb2.MovementTask.OBSTACLE_AVOID_WAIT):
        self._run_sync_threadsafe(self._protobuf.move_to_station, no, station_id, avoid_policy)

    def move_follow_path(
        self,
        no,
        paths,
        cancel_task_decetect_dmcode,
        avoid_policy=main_pb2.MovementTask.OBSTACLE_AVOID_WAIT,
    ):
        self._run_sync_threadsafe(self._protobuf.move_follow_path, no, paths, cancel_task_decetect_dmcode, avoid_policy)

    def move_pod_code(self, no, load_type: str):
        self._run_sync_threadsafe(self._protobuf.move_pod_code, no, load_type)

    def enable_manual_control_oba(self):
        self._run_sync_threadsafe(self._protobuf.enable_manual_control_oba)

    def disable_manual_control_oba(self):
        self._run_sync_threadsafe(self._protobuf.disable_manual_control_oba)

    # 追加路径
    def replace_move_path(self, no, paths, cancel_task_decetect_dmcode):
        self._run_sync_threadsafe(self._protobuf.replace_move_path, no, paths, cancel_task_decetect_dmcode)

    def pause_task(self):
        self._run_sync_threadsafe(self._protobuf.pause_task)

    def continue_task(self):
        self._run_sync_threadsafe(self._protobuf.continue_task)

    def cancel_task(self):
        self._run_sync_threadsafe(self._protobuf.cancel_task)

    def cancel_movement_task(self, soft_cancel):
        self._run_sync_threadsafe(self._protobuf.cancel_movement_task, soft_cancel)

    def set_schedule_mode(self, mode):
        self._run_async_threadsafe(self._protobuf.set_schedule_mode, mode)

    def set_manual_speed(self, vx, vy, w, cur_angle):
        self._run_sync_threadsafe(self._protobuf.set_manual_speed, vx, vy, w, cur_angle)

    def set_manual_control(self, is_manual: bool):
        if is_manual:
            self._run_sync_threadsafe(self._protobuf.enable_manual_control)
        else:
            self._run_sync_threadsafe(self._protobuf.disable_manual_control)

    def set_manual_control_oba(self, oba_active: bool):
        if oba_active:
            self._run_sync_threadsafe(self._protobuf.enable_manual_control_oba)
        else:
            self._run_sync_threadsafe(self._protobuf.disable_manual_control_oba)

    def set_traffic_control(self, enable: bool):
        if enable:
            self._run_sync_threadsafe(self._protobuf.enable_traffic_control)
        else:
            self._run_sync_threadsafe(self._protobuf.disable_traffic_control)

    def stop_location(self):
        self._run_sync_threadsafe(self._protobuf.stop_location)

    def set_current_map(self, map_name):
        self._run_sync_threadsafe(self._protobuf.set_current_map, map_name)

    def set_initial_pose(self, x: float, y: float, yaw: float, x_factor: int = 0, y_factor: int = 0):
        self._run_sync_threadsafe(self._protobuf.set_initial_pose, x, y, yaw, x_factor, y_factor)

    def start_location(self, absolute_location: bool = False, station_id: int | None = None, timeout: float = 60):
        return self._run_sync_location_threadsafe(
            self._protobuf.start_location, absolute_location, station_id, timeout=timeout
        )

    def locate_by_pose(
        self,
        x: float,
        y: float,
        yaw: int,
        x_factor: int = 0,
        y_factor: int = 0,
        absolute_location: bool = False,
        timeout: float = 60,
    ):
        self.set_initial_pose(int(round(x)), int(round(y)), yaw, x_factor, y_factor)
        return self.start_location(absolute_location=absolute_location, timeout=timeout)

    def locate_by_station(self, station_id: int, absolute_location: bool = False, timeout: float = 60):
        return self.start_location(absolute_location=absolute_location, station_id=station_id, timeout=timeout)

    def switch_map(
        self,
        map_name: str,
        x: float,
        y: float,
        yaw: float,
        absolute_location: bool = False,
        timeout: float = 60,
    ):
        return self._run_sync_location_threadsafe(
            self._protobuf.switch_map, map_name, x, y, yaw, absolute_location, timeout=timeout
        )

    def set_map_with_initial_pose(
        self,
        map_name: str,
        x: float,
        y: float,
        yaw: float,
        absolute_location: bool = False,
        timeout: float = 60,
    ):
        return self.switch_map(
            map_name,
            int(round(x)),
            int(round(y)),
            int(round(yaw)),
            absolute_location=absolute_location,
            timeout=timeout,
        )

    def start_charge(self):
        self._protobuf.start_charge(self.seq)
        # self.async_execute_action_task(no, 78, 1, 0)
        _logger.info('async_execute_action_task Start charge is successful')

    def stop_charge(self):
        self._protobuf.stop_charge(self.seq)
        # self.async_execute_action_task(no, 78, 2, 0)
        _logger.info('async_execute_action_task Stop charge is successful')

    # 同步执行，直到动作结果返回或超时
    def execute_action_task(self, no, action_id, param0, param1, paramStr=''):
        _logger.info(f'Execute action {no} {action_id} {param0} {param1} {paramStr}')
        result = self._run_sync_task_threadsafe(
            self._protobuf.execute_action_task, no, action_id, param0, param1, paramStr
        )
        return result

    # 仅等待命令应答，不等待动作完成通知
    def start_action_task(self, no, action_id, param0, param1, paramStr=''):
        _logger.info(f'Start action {no} {action_id} {param0} {param1} {paramStr}')
        return self._run_sync_threadsafe(self._protobuf.execute_action_task, no, action_id, param0, param1, paramStr)

    def cancel_action_task(self):
        self._run_sync_threadsafe(self._protobuf.cancel_action_task)

    def read_input_registers(self, start_addr, count):
        return self._run_sync_threadsafe(self._protobuf.readInputRegisters, start_addr, count)

    # 以下为异步步指令
    def async_move_to_station(self, no, station_id, avoid_policy=main_pb2.MovementTask.OBSTACLE_AVOID_WAIT):
        self._run_async_threadsafe(self._protobuf.move_to_station, no, station_id, avoid_policy)

    def async_execute_action_task(self, no, action_id, param0, param1):
        self._run_async_threadsafe(self._protobuf.execute_action_task, no, action_id, param0, param1)

    def async_reset_srp(self):
        self._run_async_threadsafe(self._protobuf.reset_srp)

    def _run_sync_threadsafe(self, fun, *args, timeout: float = 3):
        "请求同步执行直到返回结果"
        return asyncio.run_coroutine_threadsafe(
            asyncio.wait_for(self._sync_request(fun, *args), timeout), self._loop
        ).result()

    def _run_sync_task_threadsafe(self, fun, *args, timeout=10 * 60):
        """移动动作任务同步执行直到返回结果"""
        return asyncio.run_coroutine_threadsafe(
            asyncio.wait_for(self._sync_task(fun, *args), timeout), self._loop
        ).result()

    def _run_sync_location_threadsafe(self, fun, *args, timeout: float | int = 60):
        """定位任务同步执行直到返回结果"""
        return asyncio.run_coroutine_threadsafe(
            asyncio.wait_for(self._sync_location_task(fun, *args), timeout), self._loop
        ).result()

    async def _sync_request(self, func, *args):
        sequence = self.seq
        future = self._loop.create_future()
        ctx = RequestContext(sequence=sequence, future=future)
        self._seq_ctx_map[sequence] = ctx
        func(sequence, *args)

        try:
            return await future
        except asyncio.CancelledError:
            # Usually cancelled by wait_for timeout in _run_sync_threadsafe.
            _logger.warning('sync request timeout/cancelled: sequence=%s, func=%s', sequence, func.__name__)
            raise
        finally:
            self._seq_ctx_map.pop(sequence, None)

    async def _sync_task(self, func, *args):
        """同步任务请求"""
        self._task_future = self._loop.create_future()
        func(self.seq, *args)
        return await self._task_future

    async def _sync_location_task(self, func, *args):
        sequence = self.seq
        ack_future = self._loop.create_future()
        self._loc_future = self._loop.create_future()
        self._seq_ctx_map[sequence] = RequestContext(sequence=sequence, future=ack_future)
        func(sequence, *args)

        try:
            # First wait for command-level ack/reject.
            await ack_future
            # If location is already RUNNING, there may be no state transition callback.
            if (
                self._last_location_state == main_pb2.SystemState.LocationState.LOCATION_STATE_RUNNING
                and self._loc_future is not None
                and not self._loc_future.done()
            ):
                self.set_location_result(True)
            return await self._loc_future
        except asyncio.CancelledError:
            _logger.warning('sync location timeout/cancelled: sequence=%s, func=%s', sequence, func.__name__)
            raise
        finally:
            self._seq_ctx_map.pop(sequence, None)
            self._loc_future = None

    def _run_async_threadsafe(self, fun, *args):
        self._loop.call_soon_threadsafe(fun, self.seq, *args)

    async def _connect(self, ip_addr):
        """
        由于同样的ip和port链接sros经常出问题，所以此处一直用端口号为8888的端口号链接sros
        :param ip_addr:
        :return:
        """
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            SOURCE_PORT = 8888
            sock.bind(('0.0.0.0', SOURCE_PORT))
            sock.connect((ip_addr, 5001))
            self._transport, self._protocol = await self._loop.create_connection(lambda: SrpProtocol(self), sock=sock)
            return True
        except BaseException as e:
            _logger.error(f'Connect to sros failed: {e}')
        return False

    def connection_made(self, transport):
        _logger.info('connected!')

    def data_received(self, data):
        self._protobuf.onRead(data)

    def error_received(self, exc):
        _logger.error(f'Error received: {exc}')

    def connection_lost(self, exc):
        _logger.warning(f'Socket closed: {exc}')
        # Ensure callback is called even if logout might not
        if self._transport and self._callback_connect_changed:
            _logger.info('Triggering connection lost callback')
            try:
                self._callback_connect_changed(False)
            except BaseException as e:
                _logger.error(f'Error calling connect callback: {e}')
        self._transport = None
        self.logout()

    def write_callback(self, data):
        if not self._transport:
            return
        self._transport.write(data)

    def move_pause(self):
        return self._run_sync_threadsafe(self._protobuf.move_pause)

    def move_continue(self):
        return self._run_sync_threadsafe(self._protobuf.move_continue)

    def response_callback(self, sequence: int, resp_data: srp_protobuf.RespData):
        """通过序列号匹配请求，唤醒同步"""
        # Some streaming responses (e.g. lidar points) can be pushed with seq=0.
        # They have already been dispatched in protobuf handlers and do not belong
        # to any pending sync request context.
        if sequence <= 0:
            return

        ctx = self._seq_ctx_map.get(sequence, None)
        if not ctx:
            _logger.warning(f'no context for request[{sequence}]')
            return
        if not ctx.future or ctx.future.done():
            _logger.error('message context abnormal')
            return
        # 同步请求：唤醒Future
        if resp_data.ok:
            ctx.future.set_result(resp_data.value)
        else:
            ctx.future.set_exception(RequestFailedError(value=resp_data.value, result_code=resp_data.result_code))
            if resp_data.resp_type == main_pb2.Response.RESPONSE_COMMAND:
                # 动作执行失败，需要抛出异常
                if self._task_future is not None:
                    self._task_future.set_exception(
                        RequestFailedError(value=resp_data.value, result_code=resp_data.result_code)
                    )
