from dataclasses import dataclass
from typing import Protocol, TypedDict, List

from .main_pb2 import SystemState, HardwareState


@dataclass
class SrpConnectionConfig:
    ip: str
    username: str = 'admin'
    passwd: str = 'admin'


class SrpCallbackSystemState(Protocol):
    def __call__(self, system_state: SystemState) -> None: ...


class SrpCallbackHardwareState(Protocol):
    def __call__(self, hardware_state: HardwareState) -> None: ...


class SrpCallbackConnectionState(Protocol):
    def __call__(self, connected: bool) -> None: ...


class SrpCallbackEmergencyStateChanged(Protocol):
    def __call__(self, estop_active: bool) -> None: ...


class SrpCallbackDict(TypedDict):
    system_state: List[SrpCallbackSystemState]
    hardware_state: List[SrpCallbackHardwareState]
    connect_state: List[SrpCallbackConnectionState]
    emergency_state: List[SrpCallbackEmergencyStateChanged]
