import logging
import threading
import traceback
from typing import List, Optional
from .path import Path
from .main_pb2 import Path as PbPath
from .main_pb2 import ActionTask
from .action_manager import ActionManager

from .client_types import (
    SrpCallbackDict,
    SrpCallbackEmergencyStateChanged,
    SrpCallbackHardwareState,
    SrpCallbackSystemState,
    SrpConnectionConfig,
)
from .main_pb2 import HardwareState, MovementTask, SystemState

logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(name)s | %(levelname)s | %(message)s')
_logger = logging.getLogger(__name__)
_logger.addHandler(logging.NullHandler())


class SrpClient:
    _system_state_cnt = 0
    _path_task_no = 0

    _system_state: Optional[SystemState] = None
    _hardware_state: Optional[HardwareState] = None

    _callbacks: SrpCallbackDict = {
        'system_state': [],
        'hardware_state': [],
        'connect_state': [],
        'emergency_state': [],
    }

    _is_move_at_arc = False
    # 解决在切换地图/重新定位时，系统状态 LOCATION_STATE 会先重置为 NONE 导致误判为定位失败的情况
    _suppress_location_none = False
    _action_manager: ActionManager

    # Reconnection mechanism attributes
    _connection_config: Optional[SrpConnectionConfig] = None
    _is_connected = False
    _reconnect_enabled = True  # Enabled by default
    _reconnect_thread: Optional[threading.Thread] = None
    _reconnect_stop_event = threading.Event()
    _reconnect_interval = 5.0  # seconds between reconnect attempts
    _reconnect_max_attempts = 0  # 0 means infinite retries
    _intentional_disconnect = False  # Flag to indicate user-initiated disconnect

    def __init__(self):
        from .srp import SRP

        self._srp = SRP()
        self._action_manager = ActionManager()
        self._srp.set_system_state_callback(self._on_system_state)
        self._srp.set_hardware_state_callback(self._on_hardware_state)
        self._srp.set_notify_action_task_finished_callback(self._on_action_task_finished)
        self._srp.set_callback_connect(self._on_connect_state_changed)

        # Initialize per-instance reconnection state
        self._reconnect_enabled = True
        self._is_connected = False
        self._connection_config = None
        self._reconnect_thread = None
        self._reconnect_stop_event = threading.Event()
        self._reconnect_interval = 5.0
        self._reconnect_max_attempts = 0
        self._intentional_disconnect = False

    def disconnect(self):
        """Disconnect from the robot. This will NOT trigger automatic reconnection."""
        self._intentional_disconnect = True
        self._stop_reconnect()
        self._srp.logout()
        self._srp.stop()
        self._is_connected = False

    def set_laser_point_upload(self, enabled: bool):
        """
        控制雷达点主动上传开关
        :param enabled: True=打开上传，False=关闭上传
        """
        from .main_pb2 import CMD_ENABLE_AUTO_UPLOAD_LASER_POINT, CMD_DISABLE_AUTO_UPLOAD_LASER_POINT

        cmd = CMD_ENABLE_AUTO_UPLOAD_LASER_POINT if enabled else CMD_DISABLE_AUTO_UPLOAD_LASER_POINT
        return self._srp._run_sync_threadsafe(self._srp._protobuf._send_command_msg, cmd)

    def set_laser_point_callback(self, fun):
        """
        注册激光点云回调
        """
        return self._srp.set_laser_point_callback(fun)

    def get_current_system_state(self) -> Optional[SystemState]:
        return self._system_state

    def get_current_hardware_state(self) -> Optional[HardwareState]:
        return self._hardware_state

    def is_connected(self) -> bool:
        """
        Check if the client is currently connected to the robot.

        :return: True if connected, False otherwise
        """
        return self._is_connected

    def connect(self, config: SrpConnectionConfig) -> bool:
        """
        Connect to the robot.

        Example:
        >>> config = ConnectionConfig(ip="192.168.1.10")
        >>> client.connect(config)
        True
        """
        self._connection_config = config
        result = self._srp.login(config.ip, config.username, config.passwd)
        if result:
            self._is_connected = True
            if self._reconnect_enabled:
                self._start_reconnect()
        return result

    def add_system_state_callback(self, cb: SrpCallbackSystemState):
        self._callbacks['system_state'].append(cb)

    def add_hardware_state_callback(self, cb: SrpCallbackHardwareState):
        self._callbacks['hardware_state'].append(cb)

    def add_emergency_state_callback(self, cb: SrpCallbackEmergencyStateChanged):
        self._callbacks['emergency_state'].append(cb)

    def fetch_system_state(self):
        try:
            return self._srp.fetch_system_state()
        except BaseException as e:
            _logger.error(e)

    def fetch_hardware_state(self):
        try:
            return self._srp.fetch_hardware_state()
        except BaseException as e:
            _logger.error(e)

    def fetch_laser_points(self):
        try:
            return self._srp.fetch_laser_points()
        except BaseException as e:
            _logger.error(e)

    def _on_system_state(self, system_state: SystemState):
        current_system_state = self._system_state
        self._system_state = system_state
        self._action_manager.on_system_state(system_state)
        if current_system_state:
            # 处理定位成功状态
            if (
                current_system_state.location_state != SystemState.LocationState.LOCATION_STATE_RUNNING
                and system_state.location_state == SystemState.LocationState.LOCATION_STATE_RUNNING
            ):
                self._srp.set_location_result(True)

            # 处理丢失定位状态
            if (
                current_system_state.location_state != SystemState.LocationState.LOCATION_STATE_NONE
                and system_state.location_state == SystemState.LocationState.LOCATION_STATE_NONE
            ):
                # 如果开启了抑制标志，则不立即宣告失败
                if self._suppress_location_none:
                    _logger.info('Detected LOCATION_STATE_NONE, but suppression is active. Waiting for RUNNING...')
                else:
                    self._srp.set_location_result(False)

            # 处理急停状态
            if current_system_state.emergency_state != system_state.emergency_state:
                is_emergency = True
                if system_state.emergency_state in (
                    SystemState.EmergencyState.STATE_EMERGENCY_NONE,
                    SystemState.EmergencyState.STATE_EMERGENCY_NA,
                ):
                    is_emergency = False
                for callback in self._callbacks['emergency_state']:
                    callback(is_emergency)
            self._is_move_at_arc = self.is_move_at_arc(current_system_state)

        for callback in self._callbacks['system_state']:
            callback(system_state)

    def _on_action_task_finished(self, action_task: ActionTask):
        self._action_manager.on_action_finished(action_task)

    def _on_hardware_state(self, hardware_state: HardwareState):
        self._hardware_state = hardware_state
        try:
            for callback in self._callbacks['hardware_state']:
                callback(hardware_state)
        except BaseException as e:
            _logger.error(e, exc_info=True)

    def is_move_at_arc(self, system_state: SystemState) -> bool:
        if system_state.HasField('movement_state'):
            movement_state = system_state.movement_state
            if (
                movement_state.state
                in (
                    MovementTask.TaskState.MT_RUNNING,
                    MovementTask.TaskState.MT_PAUSED,
                    MovementTask.TaskState.MT_WAIT_FOR_CHECKPOINT,
                    MovementTask.TaskState.MT_IN_CANCEL,
                )
                and movement_state.cur_path_no != 0
            ):
                path_type = movement_state.paths[movement_state.cur_path_no - 1].type
                if path_type in (PbPath.PATH_BEZIER, PbPath.PATH_CIRCLE):
                    return True
        return False

    def move_to_station(self, no: int, station_id: int):
        self._srp.move_to_station(no, station_id)

    def locate_by_pose(
        self,
        x: float,
        y: float,
        yaw: float,
        force_set_initial_pose: bool = False,
        timeout_sec: float = 60.0,
    ):
        return self._srp.locate_by_pose(
            x=x,
            y=y,
            yaw=int(round(yaw)),
            absolute_location=force_set_initial_pose,
            timeout=timeout_sec,
        )

    def locate_by_station(
        self,
        station_id: int,
        force_locate: bool = False,
        timeout_sec: float = 60.0,
    ):
        return self._srp.locate_by_station(
            station_id=station_id,
            absolute_location=force_locate,
            timeout=timeout_sec,
        )

    def set_map_with_initial_pose(
        self,
        map_name: str,
        x: float,
        y: float,
        yaw: float,
        force_set_initial_pose: bool = False,
        timeout_sec: float = 60.0,
    ):
        return self._srp.set_map_with_initial_pose(
            map_name=map_name,
            x=x,
            y=y,
            yaw=int(round(yaw)),
            absolute_location=force_set_initial_pose,
            timeout=timeout_sec,
        )

    def execute_action_task(self, no: int, action_id: int, param0: int, param1: int, param_str: str = ''):
        """
        Submit an action task and track its lifecycle via srp_action_manager.
        The upper layer can call wait_action_update for long polling.
        """
        self._action_manager.submit_action(no, action_id, param0, param1, param_str)
        try:
            self._srp.start_action_task(no, action_id, param0, param1, param_str)
            return self._action_manager.get_action_status(no)
        except BaseException as e:
            result_code = 0
            if hasattr(e, 'result_code'):
                result_code = e.result_code  # type: ignore # nocheck
            self._action_manager.mark_rejected(no, result_code=result_code, result_str=str(e))
            raise

    def get_action_status(self, action_no: int):
        return self._action_manager.get_action_status(action_no)

    def wait_action_update(self, action_no: int, timeout: float = 30.0, after_revision: Optional[int] = None):
        return self._action_manager.wait_action_update(action_no, timeout=timeout, after_revision=after_revision)

    def cancel_action_task(self):
        return self._srp.cancel_action_task()

    @property
    def action_manager(self):
        return self._action_manager

    def cancel_movement_task(self, soft: bool = True):
        """
        Cancel the current movement task.
        :type soft: bool, default ``True`` whether to perform a soft cancel (decelerate to stop) or hard cancel (immediate stop).
        """
        self._srp.cancel_movement_task(soft)

    def move_follow_path(self, no: int, paths: List[Path]):
        self._srp.move_follow_path(no, paths, cancel_task_decetect_dmcode=False)

    def move_pause(self):
        _logger.info('movement pause called')
        try:
            return self._srp.move_pause()
        except BaseException as _:
            traceback.print_exc()

    def move_resume(self):
        _logger.info('movement resume called')
        try:
            return self._srp.move_continue()
        except BaseException as _:
            traceback.print_exc()

    def set_remote_control(self, enable: bool):
        return self._srp.set_manual_control(enable)

    def set_remote_control_oba(self, oba_active: bool):
        return self._srp.set_manual_control_oba(oba_active)

    def set_remote_control_speed(self, vx: int, vy: int, w: int, cur_angle: int = 0):
        return self._srp.set_manual_speed(vx, vy, w, cur_angle)

    def emergency_stop(self):
        return self._srp.trigger_emergency()

    def release_emergency_stop(self):
        return self._srp.cancel_emergency()

    # ============ Reconnection Mechanism Methods ============

    def enable_reconnect(self, interval: float = 5.0, max_attempts: int = 0):
        """
        Enable and configure automatic reconnection mechanism.

        Reconnection is ENABLED by default after client creation.
        Use this method to change reconnection parameters at runtime.

        :param interval: Time in seconds between reconnection attempts. Default is 5 seconds.
        :param max_attempts: Maximum number of reconnection attempts. 0 means infinite retries.
                           Default is 0 (infinite retries).

        Example:
        >>> client = SrpClient()
        >>> client.enable_reconnect(interval=10.0, max_attempts=20)
        >>> client.connect(config)
        """
        self._reconnect_interval = interval
        self._reconnect_max_attempts = max_attempts
        self._reconnect_enabled = True
        _logger.info(f'Reconnection enabled: interval={interval}s, max_attempts={max_attempts}')

    def disable_reconnect(self):
        """
        Completely disable automatic reconnection mechanism.

        If connection is lost after this call, no reconnection will be attempted.
        """
        self._reconnect_enabled = False
        self._stop_reconnect()
        _logger.info('Reconnection disabled')

    def _on_connect_state_changed(self, connected: bool):
        """
        Callback for connection state changes from SRP.
        This is called when SRP detects connection status change.
        """
        old_state = self._is_connected
        self._is_connected = connected
        _logger.info(f'Connection state changed: {old_state} -> {connected}')

        # Only trigger reconnection on unexpected disconnection (not intentional)
        if old_state and not connected and self._reconnect_enabled and self._connection_config:
            if self._intentional_disconnect:
                _logger.info('User initiated disconnect. Reconnection disabled for this cycle.')
                self._intentional_disconnect = False
            else:
                _logger.warning('Unexpected connection loss! Starting reconnection attempts...')
                self._start_reconnect()

        # Notify all registered callbacks
        for callback in self._callbacks['connect_state']:
            try:
                callback(connected)
            except BaseException as e:
                _logger.error(f'Error in connect_state callback: {e}', exc_info=True)

    def _start_reconnect(self):
        """
        Start the reconnection thread if not already running.
        """
        if self._reconnect_thread and self._reconnect_thread.is_alive():
            return

        self._reconnect_stop_event.clear()
        self._reconnect_thread = threading.Thread(target=self._reconnect_worker, daemon=True)
        self._reconnect_thread.start()

    def _stop_reconnect(self):
        """
        Stop the reconnection thread.
        """
        self._reconnect_stop_event.set()
        if self._reconnect_thread:
            self._reconnect_thread.join(timeout=5)
            self._reconnect_thread = None

    def _reconnect_worker(self):
        """
        Worker thread that handles automatic reconnection.
        """
        if not self._connection_config:
            _logger.error('No connection config available for reconnection')
            return

        attempt = 0

        while not self._reconnect_stop_event.is_set():
            # Check if connection was restored
            if self._is_connected:
                _logger.info('✓ Connection restored successfully')
                break

            # Check max attempts
            if self._reconnect_max_attempts > 0 and attempt >= self._reconnect_max_attempts:
                _logger.error(f'✗ Max reconnection attempts ({self._reconnect_max_attempts}) reached')
                break

            attempt += 1
            _logger.info(f'Reconnection attempt {attempt}...')

            try:
                config = self._connection_config
                result = self._srp.login(config.ip, config.username, config.passwd)
                if result:
                    self._is_connected = True
                    _logger.info(f'✓ Reconnected successfully on attempt {attempt}')
                    break
                else:
                    _logger.warning(f'✗ Reconnection attempt {attempt} failed: login returned False')
            except BaseException as e:
                _logger.error(f'✗ Reconnection attempt {attempt} failed: {type(e).__name__}: {e}')

            # Wait before next attempt (check for stop event with timeout)
            if self._reconnect_stop_event.wait(self._reconnect_interval):
                # Stop event was set, exit
                break
